import initSqlJs from "sql.js";
import { fileURLToPath } from "url";
import { dirname, join } from "path";
import fs from "fs";

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

const dbPath = join(__dirname, "geosentinel.db");
const wasmPath = join(__dirname, "../node_modules/sql.js/dist/sql-wasm.wasm");
const wasmBinary = fs.readFileSync(wasmPath);
const SQL = await initSqlJs({ wasmBinary });

// sql.js compatibility wrapper (mimics better-sqlite3 sync API)
class StatementWrapper {
  constructor(db, sql) {
    this._db = db;
    this._sql = sql;
  }
  run(...params) {
    const flat = params.flat();
    this._db.run(this._sql, flat.length ? flat : undefined);
    const row = this._db.exec("SELECT last_insert_rowid() as id");
    const lastId =
      row.length && row[0].values.length ? row[0].values[0][0] : null;
    return { lastInsertRowid: lastId, changes: 1 };
  }
  get(...params) {
    const flat = params.flat();
    const stmt = this._db.prepare(this._sql);
    stmt.bind(flat.length ? flat : undefined);
    if (stmt.step()) {
      const res = stmt.getAsObject();
      stmt.free();
      return res;
    }
    stmt.free();
    return undefined;
  }
}

class DatabaseWrapper {
  constructor(db) {
    this._db = db;
  }
  exec(sql) {
    this._db.run(sql);
    return this;
  }
  prepare(sql) {
    return new StatementWrapper(this._db, sql);
  }
  close() {
    const data = this._db.export();
    fs.writeFileSync(dbPath, Buffer.from(data));
    this._db.close();
  }
}

const db = new DatabaseWrapper(new SQL.Database());

const schema = fs.readFileSync(join(__dirname, "schema.sql"), "utf-8");
db.exec(schema);

// Clear seed data for idempotent re-runs
db.exec("DELETE FROM sos_alerts");
db.exec("DELETE FROM feedback");
db.exec("DELETE FROM danger_zones");

// Seed admin phone (demo)
try {
  db.prepare("INSERT INTO admins (phone) VALUES (?)").run("9876543210");
  console.log("Seeded admin phone: 9876543210");
} catch (e) {
  if (!e.message.includes("UNIQUE")) throw e;
}

// Seed danger zones
const dangerZones = [
  {
    lat: 28.62,
    lng: 77.22,
    radius: 600,
    name: "Yamuna River Basin",
    type: "water",
  },
  {
    lat: 28.6,
    lng: 77.2,
    radius: 300,
    name: "Construction Danger Area",
    type: "danger",
  },
  {
    lat: 28.53,
    lng: 77.24,
    radius: 450,
    name: "Okhla Lake Reserve",
    type: "water",
  },
];
const insDZ = db.prepare(
  "INSERT INTO danger_zones (lat, lng, radius, name, type) VALUES (?, ?, ?, ?, ?)",
);
for (const z of dangerZones) {
  try {
    insDZ.run(z.lat, z.lng, z.radius, z.name, z.type);
  } catch (e) {
    if (!e.message.includes("UNIQUE")) console.warn(e);
  }
}

// Seed sample users
const users = [
  {
    phone: "+911111111111",
    email: "aisha@gmail.com",
    name: "Aisha Patel",
    user_type: "indian",
    identity: "9999 8888 7777",
    emergency_contact: "1111111111",
    state: "Gujarat",
  },
];
const insUser = db.prepare(
  "INSERT OR IGNORE INTO users (phone, email, name, user_type, identity, emergency_contact, state) VALUES (?, ?, ?, ?, ?, ?, ?)",
);
for (const u of users) {
  insUser.run(
    u.phone,
    u.email,
    u.name,
    u.user_type,
    u.identity,
    u.emergency_contact,
    u.state,
  );
}

// Seed SOS alerts
const alerts = [
  {
    user_id: 1,
    user_name: "Aisha Patel",
    lat: 28.618,
    lng: 77.215,
    type: "standard",
    info: "Need directions to the hotel.",
    status: "Resolved",
  },
];
const insAlert = db.prepare(
  "INSERT INTO sos_alerts (user_id, user_name, lat, lng, type, info, status) VALUES (?, ?, ?, ?, ?, ?, ?)",
);
for (const a of alerts) {
  insAlert.run(a.user_id, a.user_name, a.lat, a.lng, a.type, a.info, a.status);
}

// Seed feedback
const feedback = [
  {
    user_name: "Tourist_42",
    message: "Great app! SOS feature saved me.",
    rating: 5,
  },
  { user_name: "Traveler_88", message: "Map loads very smoothly.", rating: 4 },
  {
    user_name: "Explorer_15",
    message: "Geofence alerts are very accurate.",
    rating: 5,
  },
];
const insFb = db.prepare(
  "INSERT INTO feedback (user_name, message, rating) VALUES (?, ?, ?)",
);
for (const f of feedback) {
  insFb.run(f.user_name, f.message, f.rating);
}

db.close();
console.log("Database initialized at", dbPath);
